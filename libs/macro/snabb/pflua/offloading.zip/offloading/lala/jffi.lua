local json =require("dkjson")
local ffi=require("ffi")

local f = io.open('out1', 'r')
local arg = f:read("*a")
local res = json.decode(arg)
local a = res.a
local b = res.b
local c = res.c
c_str = ffi.new("unsigned char [10240]", b)
l = (ffi.cast(a, c_str + c))[0]
f:close()
local haha=io.open("hahaxd", "w")
haha:write(l) --json.encode(p, {indent=true}))
haha:close()
