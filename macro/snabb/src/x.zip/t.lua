print(1LL)
