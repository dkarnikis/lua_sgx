#! /usr/bin/env luajit
--
-- ndpi.lua
-- Copyright (C) 2016-2017 Adrian Perez <aperez@igalia.com>
--
-- Distributed under terms of the Apache License 2.0.
--
return require("ndpi.wrap")
